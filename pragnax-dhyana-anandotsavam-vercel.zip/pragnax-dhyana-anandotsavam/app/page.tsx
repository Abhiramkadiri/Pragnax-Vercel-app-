"use client";

import { useEffect, useState } from "react";
import {
  ArrowDown, ArrowUpRight, CalendarDays, Check, Clock3, Flower2,
  Heart, MapPin, Menu, MoonStar, Sparkles, Sun, Users, X
} from "lucide-react";

const REGISTRATION_URL = "https://forms.gle/HN5Yux4VqWyCeWCJ8";
const EVENT_DATE = new Date("2026-11-29T09:00:00+05:30");

function Countdown() {
  const [remaining, setRemaining] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const update = () => {
      const diff = Math.max(0, EVENT_DATE.getTime() - Date.now());
      setRemaining({
        days: Math.floor(diff / 86400000),
        hours: Math.floor((diff / 3600000) % 24),
        minutes: Math.floor((diff / 60000) % 60),
        seconds: Math.floor((diff / 1000) % 60)
      });
    };
    update();
    const timer = window.setInterval(update, 1000);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <div className="countdown" aria-label="Countdown to the event">
      {[
        ["Days", remaining.days],
        ["Hours", remaining.hours],
        ["Minutes", remaining.minutes],
        ["Seconds", remaining.seconds]
      ].map(([label, value]) => (
        <div className="count-unit" key={label}>
          <strong>{String(value).padStart(2, "0")}</strong>
          <span>{label}</span>
        </div>
      ))}
    </div>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const closeMenu = () => setMenuOpen(false);

  return (
    <main>
      <div className="announcement">
        <span className="announcement-dot" />
        29 NOVEMBER 2026 <span className="announcement-divider">•</span> KHAIRATABAD, HYDERABAD
      </div>

      <header className="nav-wrap">
        <nav className="nav container">
          <a className="brand" href="#home" onClick={closeMenu} aria-label="PRAGNAX home">
            <span className="brand-mark"><Flower2 size={25} strokeWidth={1.5} /></span>
            <span>PRAGNAX<small>GROW WITH AWARENESS</small></span>
          </a>
          <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">
            {menuOpen ? <X /> : <Menu />}
          </button>
          <div className={`nav-links ${menuOpen ? "open" : ""}`}>
            <a href="#about" onClick={closeMenu}>About</a>
            <a href="#experience" onClick={closeMenu}>The experience</a>
            <a href="#details" onClick={closeMenu}>Event details</a>
            <a className="nav-cta" href={REGISTRATION_URL} target="_blank" rel="noreferrer" onClick={closeMenu}>
              Register now <ArrowUpRight size={16} />
            </a>
          </div>
        </nav>
      </header>

      <section className="hero" id="home">
        <div className="hero-orb orb-one" />
        <div className="hero-orb orb-two" />
        <div className="hero-content container">
          <div className="eyebrow"><span /> A CELEBRATION OF INNER STILLNESS <span /></div>
          <h1>Find your<br /><em>inner</em> harmony.</h1>
          <p className="hero-subtitle">Dhyana Anandotsavam</p>
          <p className="hero-copy">
            A gathering to pause, reconnect and celebrate the joy of meditation.
            Come together for a day centred on awareness, peace and collective well-being.
          </p>
          <div className="hero-actions">
            <a className="button button-primary" href={REGISTRATION_URL} target="_blank" rel="noreferrer">
              Be part of the celebration <ArrowUpRight size={18} />
            </a>
            <a className="text-link" href="#details">Explore the event <ArrowDown size={16} /></a>
          </div>
          <div className="hero-meta">
            <div><CalendarDays size={18} /><span><b>29 November 2026</b><small>Sunday</small></span></div>
            <div><MapPin size={18} /><span><b>Visvesvaraya Auditorium</b><small>Khairatabad, Hyderabad</small></span></div>
          </div>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="sun-halo" />
          <div className="sun-core" />
          <div className="orbit orbit-a" />
          <div className="orbit orbit-b" />
          <div className="lotus"><Flower2 size={170} strokeWidth={0.65} /></div>
          <span className="art-caption">BREATHE IN · BE PRESENT</span>
        </div>
        <div className="hero-bottom container"><span>01 / A MOMENT FOR YOU</span><span>SCROLL TO DISCOVER ↓</span></div>
      </section>

      <section className="intro section-pad" id="about">
        <div className="container intro-grid">
          <div className="section-kicker">THE THOUGHT BEHIND IT <span>✳</span></div>
          <div>
            <h2>Make space for<br /><em>what matters.</em></h2>
            <p className="large-copy">
              In the rhythm of everyday life, a moment of stillness can change everything.
              Dhyana Anandotsavam is an invitation to turn inward, share positive energy
              and experience the joy of meditation together.
            </p>
            <p className="muted-copy">
              Presented by PRAGNAX, with a spirit of awareness, community and well-being.
            </p>
          </div>
        </div>
      </section>

      <section className="experience section-pad" id="experience">
        <div className="container">
          <div className="section-heading">
            <div className="section-kicker">A DAY TO RECONNECT <span>✳</span></div>
            <h2>More than a moment.<br /><em>A meaningful experience.</em></h2>
            <p>Come as you are. Make room for calm, connection and a renewed sense of purpose.</p>
          </div>
          <div className="experience-grid">
            <article className="experience-card card-one">
              <div className="card-icon"><MoonStar /></div><span className="card-number">01</span>
              <h3>Stillness</h3><p>Take a pause from the noise and make space for inner quiet.</p>
            </article>
            <article className="experience-card card-two">
              <div className="card-icon"><Sun /></div><span className="card-number">02</span>
              <h3>Awareness</h3><p>Reconnect with the present moment and the energy within.</p>
            </article>
            <article className="experience-card card-three">
              <div className="card-icon"><Users /></div><span className="card-number">03</span>
              <h3>Togetherness</h3><p>Share a collective celebration rooted in positivity and well-being.</p>
            </article>
          </div>
        </div>
      </section>

      <section className="count-section section-pad">
        <div className="container count-inner">
          <div><div className="section-kicker light-kicker">THE COUNTDOWN BEGINS <span>✳</span></div>
            <h2>One day. One intention.<br /><em>A world of possibility.</em></h2>
            <p>We look forward to welcoming you.</p>
          </div>
          <Countdown />
        </div>
      </section>

      <section className="details section-pad" id="details">
        <div className="container details-grid">
          <div>
            <div className="section-kicker">SAVE YOUR PLACE <span>✳</span></div>
            <h2>We'll meet<br /><em>in stillness.</em></h2>
            <p className="details-copy">Mark your calendar and join us for Dhyana Anandotsavam 2026.</p>
            <a className="button button-primary" href={REGISTRATION_URL} target="_blank" rel="noreferrer">
              Register for the event <ArrowUpRight size={18} />
            </a>
          </div>
          <div className="event-card">
            <div className="event-card-top"><span>EVENT DETAILS</span><Flower2 size={23} /></div>
            <div className="event-detail"><CalendarDays /><div><small>DATE</small><b>Sunday, 29 November 2026</b></div></div>
            <div className="event-detail"><MapPin /><div><small>VENUE</small><b>Visvesvaraya Auditorium</b><span>Khairatabad, Hyderabad, Telangana</span></div></div>
            <div className="event-detail"><Clock3 /><div><small>TIME</small><b>To be announced</b></div></div>
            <div className="event-card-bottom"><span>ORGANISED BY</span><strong>PRAGNAX</strong></div>
          </div>
        </div>
      </section>

      <section className="closing">
        <div className="closing-symbol"><Flower2 size={35} /></div>
        <p>Let the mind be still.<br /><em>Let the joy unfold.</em></p>
        <a href={REGISTRATION_URL} target="_blank" rel="noreferrer">Join the celebration <ArrowUpRight size={17} /></a>
      </section>

      <footer className="footer">
        <div className="container footer-inner">
          <a className="brand footer-brand" href="#home"><span className="brand-mark"><Flower2 size={23} /></span><span>PRAGNAX<small>GROW WITH AWARENESS</small></span></a>
          <span>© 2026 PRAGNAX. Dhyana Anandotsavam.</span>
          <a href="https://www.google.com/maps/search/?api=1&query=Visvesvaraya+Auditorium+Khairatabad+Hyderabad" target="_blank" rel="noreferrer">Find the venue <ArrowUpRight size={14} /></a>
        </div>
      </footer>
    </main>
  );
}
